"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Trash2 } from "lucide-react"
import Link from "next/link"
import type { Product } from "@/lib/types"

interface CourseEditFormProps {
  product: Product
}

export function CourseEditForm({ product }: CourseEditFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [title, setTitle] = useState(product.title)
  const [description, setDescription] = useState(product.description || "")
  const [price, setPrice] = useState((product.price_cents / 100).toString())
  const [includesCommunity, setIncludesCommunity] = useState(product.includes_community)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    const supabase = createClient()

    try {
      const { error: updateError } = await supabase
        .from("products")
        .update({
          title,
          description,
          price_cents: Math.round(Number.parseFloat(price) * 100),
          includes_community: includesCommunity,
        })
        .eq("id", product.id)

      if (updateError) throw updateError

      router.refresh()
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this course?")) return

    const supabase = createClient()
    const { error } = await supabase.from("products").delete().eq("id", product.id)

    if (error) {
      setError(error.message)
    } else {
      router.push("/app/courses")
    }
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <Link
          href="/app/courses"
          className="mb-4 inline-flex items-center text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to courses
        </Link>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">{product.title}</h1>
            <div className="mt-1 flex items-center gap-2">
              <Badge variant={product.status === "published" ? "default" : "outline"} className="capitalize">
                {product.status}
              </Badge>
            </div>
          </div>
          <Button asChild>
            <Link href={`/app/courses/${product.id}/builder`}>Course builder</Link>
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="max-w-2xl space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Course Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="title">Title</Label>
              <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="price">Price (USD)</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                min="0"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                required
              />
            </div>
            <div className="flex items-center justify-between rounded-lg border border-border p-4">
              <div>
                <p className="font-medium">Include community access</p>
                <p className="text-sm text-muted-foreground">Students will get access to your community</p>
              </div>
              <Switch checked={includesCommunity} onCheckedChange={setIncludesCommunity} />
            </div>
          </CardContent>
        </Card>

        {error && <div className="rounded-lg bg-destructive/10 p-4 text-sm text-destructive">{error}</div>}

        <div className="flex justify-between">
          <div className="flex gap-4">
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Saving..." : "Save changes"}
            </Button>
            <Button type="button" variant="outline" asChild>
              <Link href="/app/courses">Cancel</Link>
            </Button>
          </div>
          <Button type="button" variant="destructive" onClick={handleDelete}>
            <Trash2 className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </form>
    </div>
  )
}
